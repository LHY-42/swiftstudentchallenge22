import Foundation
import SwiftUI

struct Info {
    let treeimage: String
    let footprintlist: [Int]
    let itemsList: [String]
    var footprint: Int
    let climatechangegraph : String
}

var information = Info(
    treeimage: "tree",
    
    footprintlist: [
        83,
        33,
        1300,
        3500,
        350,
        
        
    ],
    itemsList : [
        "Plastic Bottle",
        "Plastic Bag",
        "Toilet Paper (1 roll)",
        "Mobile Phone (1 hour)",
        "Latte"
    ],
    footprint:0,
    climatechangegraph: "climatechangegraph"
)
