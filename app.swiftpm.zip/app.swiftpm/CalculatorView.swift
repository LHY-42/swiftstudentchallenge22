//
//  CalculatorView.swift
//  app
//
//  Created by hy loh on 23/4/22.
//

import SwiftUI

struct SheetView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack{
            
        
        Text("Your Carbon Footprint")
            .font(.largeTitle)
            .fontWeight(.bold)
            .padding()
        ZStack{
            Circle()
                .stroke(lineWidth: 20.0)
                .opacity(0.3)
                .foregroundColor(Color.red)
                .frame(width: 150.0, height: 150.0)
            Circle()
                .trim(from: 0.0, to: CGFloat(information.footprint)/28000)
                .stroke(style: StrokeStyle(lineWidth: 20.0, lineCap: .round, lineJoin: .round))
                .foregroundColor(Color.red)
                .frame(width: 150.0, height: 150.0)
            if information.footprint == 0{
                Text("No footprint")
            }
            else{
                Text("\(information.footprint)")
            }
        }
        
        
        
        Button("Press to dismiss") {
            dismiss()
        }
        .font(.title)
        .padding()
        }}
}
struct MultipleSelectionRow: View {
    var title: String
    var isSelected: Bool
    var action: () -> Void
    
    var body: some View {
        Button(action: self.action) {
            HStack {
                Text(self.title)
                if self.isSelected {
                    Spacer()
                    Image(systemName: "checkmark")
                }
            }
        }
        .foregroundColor(.black)
    }
}
struct CalculatorView: View {
    @State private var footprint = 0
    @State private var showingSheet = false
    @State var selections: [String] = []
    @State var itemcount = 0
    @State var indexlist:[Int] = []
    @State var sum = 0
    @State var sumcount = 0
    
    var body: some View {
        VStack{
            NavigationView {
                // The Multiple Selection pane was sourced from https://stackoverflow.com/questions/57022615/select-multiple-items-in-swiftui-list#:~:text=The%20only%20way%20to%20get,actually%20trying%20to%20edit%20anything. as SwiftUI does not natively support multiple selectiom
                List {
                    ForEach(information.itemsList, id: \.self) { item in
                        MultipleSelectionRow(title: item, isSelected: self.selections.contains(item)) {
                            if self.selections.contains(item) {
                                self.selections.removeAll(where: { $0 == item })
                                print("\(selections)")

                            }
                            else {
                                self.selections.append(item)
                                print("\(selections)")
                            }
                        }
                    }
                }
                .navigationTitle("Items used")
                
                
            }
            Button("Calculate Footprint") {
                
                indexlist = []
                itemcount = 0
                sum = 0
                sumcount = 0
                for item in self.selections{
                    indexlist.append(information.itemsList.firstIndex(of:item)!)
                }
                for i in indexlist{
                    sum += information.footprintlist[i]
                    print(sum)
                }
                information.footprint = sum
                
                showingSheet.toggle()
            }
            .font(.title)
            .padding()
            .sheet(isPresented: $showingSheet) {
                SheetView()
            }
            
        }
    }
    
    struct CalculatorView_Previews: PreviewProvider {
        static var previews: some View {
            CalculatorView()
        }
    }
    
}


