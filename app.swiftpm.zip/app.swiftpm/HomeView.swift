//
//  HomeView.swift
//  app
//
//  Created by hy loh on 23/4/22.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack{
            Text("Decarbonify")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            Image(information.treeimage)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(10)
                .padding(40)
            
            Text("The destruction of nature is widespread. ")
            Text("Help stop this crisis by reducing your carbon footprint.")
            
            
            
            
        }}
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
