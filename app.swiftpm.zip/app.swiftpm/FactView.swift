//
//  FactView.swift
//  app
//
//  Created by hy loh on 23/4/22.
//


import SwiftUI

struct FactView: View {
    var body: some View {
        VStack{
        Text("Statistics")
            .font(.largeTitle)
            .fontWeight(.bold)
            .padding()
        Image(information.climatechangegraph)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .cornerRadius(10)
            .padding(40)
        
            
            .frame(height: 350)
        Text("Due to carbon emissions, among several factors, the earth's temperature is increasing drastically. We need to take dramatic action to combat this crisis.")
            
            
            
        
        }}
}

struct FactView_Previews: PreviewProvider {
    static var previews: some View {
        FactView()
    }
}
