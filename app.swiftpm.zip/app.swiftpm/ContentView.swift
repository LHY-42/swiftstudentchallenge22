import SwiftUI

struct ContentView: View {
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("", systemImage: "house")
                }
            FactView()
                .tabItem{
                    Label("Statistics", systemImage: "chart.xyaxis.line")
                }
            CalculatorView()
                .tabItem{
                    Label("Calculator", systemImage:"plus.forwardslash.minus")
                }
            /**CreditView()
                .tabItem{
                    Label("", systemImage:"")
                }**/
            
        }
        
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
